package kz.aitu.oop.practice.assignment6.factory.button;

public interface Button {
    void render();
    void onClick();
}
