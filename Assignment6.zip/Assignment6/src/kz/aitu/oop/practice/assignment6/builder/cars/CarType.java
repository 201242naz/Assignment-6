package kz.aitu.oop.practice.assignment6.builder.cars;

public enum CarType {
    CITY_CAR, SPORTS_CAR, SUV
}


